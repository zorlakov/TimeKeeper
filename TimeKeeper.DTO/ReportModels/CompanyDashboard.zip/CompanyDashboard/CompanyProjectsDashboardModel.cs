﻿namespace TimeKeeper.DTO.ReportModels.CompanyDashboard
{
    public class CompanyProjectsDashboardModel
    {
        public MasterModel Project { get; set; }
        public decimal Revenue { get; set; }
    }
}